import tkinter as tk
from tkinter import messagebox
import random
import string
import pyperclip

def generate_password():
    try:
        length = int(length_entry.get())

        if length < 4:
            raise ValueError("Length must be at least 4")

        use_upper = upper_var.get()
        use_lower = lower_var.get()
        use_digits = digit_var.get()
        use_symbols = symbol_var.get()
        exclude_chars = exclude_entry.get()
  
        char_pool = ""
        if use_upper:
            char_pool += string.ascii_uppercase
        if use_lower:
            char_pool += string.ascii_lowercase
        if use_digits:
            char_pool += string.digits
        if use_symbols:
            char_pool += string.punctuation

        if not char_pool:
            raise ValueError("Select at least one character type!")

        # Exclude characters
        char_pool = ''.join(c for c in char_pool if c not in exclude_chars)

        if len(char_pool) == 0:
            raise ValueError("No characters left after exclusions!")

        password = ''.join(random.choice(char_pool) for _ in range(length))

        # Display and copy
        password_entry.delete(0, tk.END)
        password_entry.insert(0, password)
        pyperclip.copy(password)

    except ValueError as ve:
        messagebox.showerror("Invalid Input", str(ve))

# GUI Setup
root = tk.Tk()
root.title("Advanced Password Generator")
root.geometry("400x450")
root.resizable(False, False)

tk.Label(root, text="Password Length:").pack(pady=5)
length_entry = tk.Entry(root)
length_entry.insert(0, "12")
length_entry.pack()

# Options
upper_var = tk.BooleanVar(value=True)
lower_var = tk.BooleanVar(value=True)
digit_var = tk.BooleanVar(value=True)
symbol_var = tk.BooleanVar(value=False)

tk.Checkbutton(root, text="Include Uppercase Letters", variable=upper_var).pack()
tk.Checkbutton(root, text="Include Lowercase Letters", variable=lower_var).pack()
tk.Checkbutton(root, text="Include Numbers", variable=digit_var).pack()
tk.Checkbutton(root, text="Include Symbols (!@#$...)", variable=symbol_var).pack()

tk.Label(root, text="Characters to Exclude:").pack(pady=5)
exclude_entry = tk.Entry(root)
exclude_entry.insert(0, "Il1O0")  # Common confusing characters
exclude_entry.pack()

tk.Button(root, text="Generate Password", command=generate_password).pack(pady=10)

tk.Label(root, text="Generated Password:").pack(pady=5)
password_entry = tk.Entry(root, width=30, font=("Arial", 12))
password_entry.pack()

tk.Label(root, text="Password will be auto-copied to clipboard.", fg="green").pack(pady=10)

root.mainloop()

