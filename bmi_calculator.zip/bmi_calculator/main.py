# main.py
import tkinter as tk
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
import os
from datetime import datetime

data_file = "data/bmi_data.csv"
os.makedirs("data", exist_ok=True)

def calculate_bmi():
    try:
        name = name_entry.get().strip()
        weight = float(weight_entry.get())
        height = float(height_entry.get())

        if not name or weight <= 0 or height <= 0:
            raise ValueError("Invalid input")

        height_m = height / 100
        bmi = round(weight / (height_m ** 2), 2)
        category = interpret_bmi(bmi)

        result_label.config(text=f"{name}, Your BMI is {bmi} ({category})")
        save_data(name, weight, height, bmi, category)
    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numeric values.")

def interpret_bmi(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 24.9:
        return "Normal weight"
    elif 25 <= bmi < 29.9:
        return "Overweight"
    else:
        return "Obese"

def save_data(name, weight, height, bmi, category):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_entry = pd.DataFrame([[now, name, weight, height, bmi, category]],
                             columns=["Timestamp", "Name", "Weight", "Height", "BMI", "Category"])

    if os.path.exists(data_file):
        df = pd.read_csv(data_file)
        df = pd.concat([df, new_entry], ignore_index=True)
    else:
        df = new_entry

    df.to_csv(data_file, index=False)

def show_history():
    if not os.path.exists(data_file):
        messagebox.showinfo("No Data", "No BMI records found.")
        return

    df = pd.read_csv(data_file)
    history_window = tk.Toplevel(root)
    history_window.title("BMI History")
    history_text = tk.Text(history_window, width=80, height=20)
    history_text.pack()
    history_text.insert(tk.END, df.to_string(index=False))

def plot_bmi_trend():
    if not os.path.exists(data_file):
        messagebox.showinfo("No Data", "No BMI records found.")
        return

    df = pd.read_csv(data_file)
    name = name_entry.get().strip()
    user_data = df[df["Name"] == name]

    if user_data.empty:
        messagebox.showinfo("No User Data", "No BMI records found for this user.")
        return

    plt.figure(figsize=(8, 4))
    plt.plot(pd.to_datetime(user_data["Timestamp"]), user_data["BMI"], marker='o')
    plt.title(f"BMI Trend for {name}")
    plt.xlabel("Date")
    plt.ylabel("BMI")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# GUI Design
root = tk.Tk()
root.title("Advanced BMI Calculator")
root.geometry("400x400")

tk.Label(root, text="Name").pack()
name_entry = tk.Entry(root)
name_entry.pack()

tk.Label(root, text="Weight (kg)").pack()
weight_entry = tk.Entry(root)
weight_entry.pack()

tk.Label(root, text="Height (cm)").pack()
height_entry = tk.Entry(root)
height_entry.pack()

tk.Button(root, text="Calculate BMI", command=calculate_bmi).pack(pady=10)
result_label = tk.Label(root, text="")
result_label.pack()

tk.Button(root, text="Show BMI History", command=show_history).pack(pady=5)
tk.Button(root, text="Plot BMI Trend", command=plot_bmi_trend).pack(pady=5)

root.mainloop()
