import requests

def get_weather(city, api_key):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        'q': city,
        'appid': api_key,
        'units': 'metric'
    }
    
    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if response.status_code != 200:
            print(f"❌ Error: {data.get('message', 'Unable to fetch data.')}")
            return

        weather = {
            'City': data['name'],
            'Temperature': f"{data['main']['temp']} °C",
            'Humidity': f"{data['main']['humidity']}%",
            'Condition': data['weather'][0]['description'].capitalize()
        }

        print("\n🌤️  Weather Information:")
        for key, value in weather.items():
            print(f"{key}: {value}")
    
    except requests.exceptions.RequestException as e:
        print("⚠️ Network Error:", e)

def main():
    print("==== Weather App ====")
    api_key = "0673b39858ced5b3f7ed6f0b783da94eche"  # Replace with your actual key
    while True:
        city = input("\nEnter city name (or 'exit' to quit): ").strip()
        if city.lower() == 'exit':
            print("Goodbye! 👋")
            break
        elif city:
            get_weather(city, api_key)
        else:
            print("⚠️ Please enter a valid city name.")

if __name__ == "__main__":
    main()

